#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash start.sh --batch --trace < examples.txt
